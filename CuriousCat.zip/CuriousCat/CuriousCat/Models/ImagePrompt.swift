import SwiftUI

struct ImagePrompt {
    var image: UIImage
    var prompt: String
    var generatedImage: UIImage
    var catText: String
}
